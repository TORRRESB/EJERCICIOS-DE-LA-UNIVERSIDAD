class Estiven:
    def __init__(self, nombre, ocupacion, carrera, altura):
        self.nombre = nombre
        self.ocupacion = ocupacion
        self.carrera = carrera
        self.altura = altura

    def sound(self):
        print(f"{self.nombre} dice: Soy un {self.ocupacion}, mi carrera es {self.carrera}, y mi altura es de {self.altura}m")

# Crear objeto
persona1 = Estiven("Estiven", "estudiante", "ingeniería", 1.72)

# Llamar al método
persona1.sound()
