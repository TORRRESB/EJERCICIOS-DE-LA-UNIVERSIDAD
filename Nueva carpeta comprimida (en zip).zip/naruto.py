class Naruto:
    def __init__(self, nombre, aldea, nivel):
        self.nombre = nombre
        self.aldea = aldea
        self.nivel = nivel

    def presentarse(self):
        print(f"¡Hola! Soy {self.nombre} de la aldea {self.aldea}, y soy un ninja nivel {self.nivel}.")

    def atacar(self):
        print(f"{self.nombre} lanza un poderoso golpe de taijutsu ")

    def usar_jutsu(self):
        print(f"{self.nombre} usa su jutsu: ¡Rasengan! ")

    def descansar(self):
        print(f"{self.nombre} está descansando para recuperar chakra ")


ninja1 = Naruto("Naruto Uzumaki", "Konoha", "Jōnin")


ninja1.presentarse()
ninja1.usar_jutsu()
ninja1.atacar()
ninja1.descansar()
