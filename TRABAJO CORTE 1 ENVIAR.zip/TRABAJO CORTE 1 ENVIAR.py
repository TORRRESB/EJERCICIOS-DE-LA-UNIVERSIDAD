usuarios= {
    "estiven": "1234",
    "cristian": "V1000",
    "daniel": "j1234",
    "Admin": "administrador1234"
 }
##lista
mensajes= [" Bienvenido denuevo: "," Hola otra vez, "," Que gusto verte!!! "]

#la tuplar%

asignacion = ("usuario","admin")

#LOGIN

usuario = input(" ingrese su usuario: ")
contraseña = input(" Ingrese su contraseña: ")

if usuario in usuarios and usuarios[usuario] == contraseña:
    print(mensajes[0], usuario)

    if usuario == "admin":
        print(f"Tienes rol: {asignacion[2]}")
    else:
        print(f"Tienes rol: {asignacion[0]}")
else:
    print("\nUsuario o contraseña incorrectos")


